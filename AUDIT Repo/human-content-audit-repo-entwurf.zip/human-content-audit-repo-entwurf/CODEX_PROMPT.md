# Codex-Prompt: eigenes Open-Source-Repo vorbereiten

Baue aus dem Konzept ein eigenständiges, generisches Open-Source-Repo mit dem Namen:

`human-content-audit`

Ziel:
Ein wiederverwendbares Audit- und Freigabesystem für KI-generierte, KI-unterstützte oder geänderte Inhalte.

Das Repo soll nicht speziell an den KI-Kompetenz Campus gebunden sein, sondern generisch für Webseiten, SaaS-Plattformen, E-Learning, Marketingtexte, Rechtstexte, Übersetzungen und QM-Dokumentation verwendbar sein.

## Mindestumfang MVP

- ContentAuditItem Datenmodell
- ContentAuditLog Datenmodell
- ContentReviewChecklist Datenmodell
- Content-Hash-Funktion
- Änderungserkennung
- Statusmaschine
- Risk-Word-Scanner
- Übersetzungsstatus
- Review-Workflow
- einfache Admin-UI-Komponenten
- JSON/CSV Export
- Dokumentation

## Wichtige Regeln

- keine echten Firmendaten einbauen
- keine privaten Inhalte einbauen
- keine API-Keys
- keine Plattform-spezifischen Kursinhalte
- keine Rechtsberatung behaupten
- keine Compliance-Garantie behaupten
- keine ISO-Garantie behaupten

## Saubere Positionierung

Dieses System unterstützt dokumentierte menschliche Prüfung.
Es ersetzt keine Rechtsberatung, keine Datenschutzprüfung, keine ISO-Zertifizierung und kein behördliches Audit.

## Akzeptanzkriterien

Fertig erst, wenn:

- README verständlich ist
- Datenmodell dokumentiert ist
- Workflow dokumentiert ist
- Risk-Word-Scanner dokumentiert ist
- i18n/Übersetzungsprüfung dokumentiert ist
- Next.js/Prisma-Integration beschrieben ist
- keine privaten Projektdaten enthalten sind
- Repo generisch verwendbar ist
