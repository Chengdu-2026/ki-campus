# Risk Word Scan

## Zweck

Das System soll riskante oder irreführende Formulierungen erkennen und als Review-Risiko markieren.

## Riskante Begriffe

- staatlich anerkannt
- offiziell zertifiziert
- EU-zertifiziert
- ISO-zertifiziert
- behördlich anerkannt
- rechtssicher garantiert
- vollständig compliant
- vollständig AI-Act-konform
- garantiert AI-Act-konform
- ersetzt Rechtsberatung
- ersetzt Datenschutzprüfung
- ersetzt Audit
- Zertifizierung garantiert
- Führerschein offiziell
- behördliche Zulassung

## Reaktion

Wenn ein Begriff gefunden wird:

- `riskLevel` mindestens HIGH
- Status `NEEDS_REVIEW`
- AuditLog-Eintrag `LEGAL_RISK_FLAGGED`
- Hinweis: „Riskante Formulierung gefunden“

## Saubere Alternativen

- privater Schulungsnachweis
- privater Kompetenznachweis
- unterstützt die Dokumentation
- Schulung mit Abschlusstest
- Zertifikat nach bestandener Schulung
- unterstützt dokumentierte Qualitätsprozesse
- ersetzt keine Rechtsberatung
