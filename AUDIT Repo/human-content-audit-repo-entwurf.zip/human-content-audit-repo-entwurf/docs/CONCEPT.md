# Konzept: Human Content Audit

## Grundidee

Viele Unternehmen verwenden KI für Texte, Übersetzungen, Produktbeschreibungen, Lerninhalte, Marketingseiten oder interne Dokumentation.

Das Problem: Später weiß niemand mehr genau:

- Wurde dieser Text von KI erstellt?
- Wer hat ihn geprüft?
- Welche Version wurde geprüft?
- Wurde der Text nach der Freigabe geändert?
- Ist die Übersetzung geprüft oder nur maschinell erzeugt?
- Stehen riskante Formulierungen online?

`human-content-audit` soll genau diese Lücke schließen.

## Kernprinzip

1. Inhalt wird erstellt oder geändert.
2. System berechnet einen Content-Hash.
3. Inhalt wird automatisch auf `NEEDS_REVIEW` gesetzt.
4. Mensch prüft Inhalt anhand einer Checkliste.
5. Prüfung wird mit Prüfer, Zeit, Version und Hash gespeichert.
6. Wenn sich der Inhalt ändert, verfällt die alte Freigabe.
7. Admin sieht jederzeit ungeprüfte oder riskante Inhalte.

## Besonders geeignet für KI-Inhalte

Das System ist nicht nur für KI-Inhalte nutzbar, aber besonders dort sinnvoll.

KI-generierte Inhalte können fachlich falsch, rechtlich riskant, veraltet, zu werblich oder irreführend sein. Eine dokumentierte menschliche Freigabe wird dadurch wichtiger.

## Zielgruppen

- SaaS-Anbieter
- Marketingabteilungen
- Agenturen
- E-Learning-Anbieter
- Compliance-Abteilungen
- QM-Abteilungen
- Übersetzungsagenturen
- Unternehmen mit KI-generierten Webseiteninhalten
- Plattformen mit vielen dynamischen Texten
