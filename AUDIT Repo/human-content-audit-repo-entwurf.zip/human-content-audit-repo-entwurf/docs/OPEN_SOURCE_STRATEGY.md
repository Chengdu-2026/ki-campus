# Open-Source-Strategie

## Einschätzung

Das System eignet sich als eigenes öffentliches Repo, weil es generisch nutzbar ist.

Nicht nur KI-Schulungsplattformen brauchen so etwas, sondern jede Organisation, die KI-generierte Inhalte veröffentlicht oder intern verwendet.

## Was öffentlich sein sollte

- generisches Datenmodell
- Review-Workflow
- Content-Hash-Logik
- Risk-Word-Scanner
- i18n/Translation-Review
- Beispiel-Admin-UI
- Exportlogik
- Dokumentation

## Was nicht öffentlich sein sollte

- echte Firmendaten
- interne Prompts
- private Roadmap
- Kundenlogik
- vollständige Kursinhalte
- API-Keys
- interne Admin-Rollen mit echten Namen
- rechtliche Spezialtexte

## Mögliche Produktstrategie

Open Source Core:

- Content Hash
- Audit Item
- Audit Log
- Review Checklist
- Risk Word Scan
- CSV Export

Paid / Hosted Version:

- Team-Funktionen
- PDF-Audit-Reports
- Rollen/Rechte
- GitHub/CMS-Integrationen
- Workflow-Automation
- erweiterter Risk Scanner
- SaaS-Dashboard

## Claim

Englisch:

```text
Human review workflow for AI-generated content. Track what changed, who reviewed it, and whether it is safe to publish.
```

Deutsch:

```text
Audit- und Freigabesystem für KI-generierte Inhalte. Damit nachvollziehbar bleibt, was geändert, geprüft und freigegeben wurde.
```
