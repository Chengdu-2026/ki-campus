# Datenmodell

## ContentAuditItem

Repräsentiert einen prüfungspflichtigen Inhalt.

Felder:

- id
- entityType
- entityId
- entitySlug optional
- title
- locale
- source
- status
- riskLevel
- contentHash
- version
- currentContentSnapshot
- previousContentSnapshot optional
- changeSummary optional
- aiGenerated boolean
- generatedBy optional
- reviewedById optional
- reviewedAt optional
- approvedById optional
- approvedAt optional
- publishedAt optional
- rejectionReason optional
- notes optional
- createdAt
- updatedAt

## Entity Types

- MARKETING_PAGE
- COURSE
- MODULE
- LESSON
- QUESTION
- ANSWER_OPTION
- CERTIFICATE_TEMPLATE
- EMAIL_TEMPLATE
- QM_TEXT
- LEGAL_PAGE
- TRANSLATION
- FEATURE_TEXT
- UI_TEXT
- OTHER

## Source

- AI_GENERATED
- HUMAN_CREATED
- AI_ASSISTED
- IMPORTED
- TRANSLATED
- SYSTEM_GENERATED

## Status

- DRAFT
- NEEDS_REVIEW
- IN_REVIEW
- CHANGES_REQUESTED
- APPROVED
- REJECTED
- PUBLISHED
- ARCHIVED

## Risk Level

- LOW
- MEDIUM
- HIGH
- CRITICAL

## ContentAuditLog

Unveränderbare Historie aller Aktionen.

Felder:

- id
- auditItemId
- userId
- action
- oldStatus optional
- newStatus optional
- comment optional
- metadata JSON optional
- createdAt

Aktionen:

- CREATED
- AI_GENERATED
- CONTENT_CHANGED
- REVIEW_REQUESTED
- REVIEW_STARTED
- APPROVED
- REJECTED
- CHANGES_REQUESTED
- PUBLISHED
- ARCHIVED
- TRANSLATION_FLAGGED
- LEGAL_RISK_FLAGGED
- OWNER_APPROVED

## ContentReviewChecklist

Felder:

- id
- auditItemId
- reviewerId
- languageChecked boolean
- factualChecked boolean
- legalRiskChecked boolean
- aiActWordingChecked boolean
- noFalseCertificationClaims boolean
- noIsoGuaranteeClaims boolean
- noLegalAdviceClaims boolean
- noHardcodedTextChecked boolean
- i18nChecked boolean
- translationDisclaimerChecked boolean
- approvedForPublication boolean
- notes optional
- createdAt
- updatedAt
