# Integration in Next.js / Prisma

## Ziel

Das System kann als Modul in eine Next.js-App integriert werden.

## Empfohlene Komponenten

```text
src/audit/contentHash.ts
src/audit/riskScanner.ts
src/audit/statusMachine.ts
src/audit/createAuditItem.ts
src/audit/approveContent.ts
src/audit/requestChanges.ts
src/ui/ContentAuditTable.tsx
src/ui/ContentAuditDetail.tsx
src/ui/ReviewChecklist.tsx
```

## Admin-Routen

```text
/admin/content-audit
/admin/content-audit/[id]
```

## Admin-Dashboard

Anzeigen:

- neue Inhalte zur Prüfung
- geänderte Inhalte zur Prüfung
- Übersetzungen zur Prüfung
- freigegebene Inhalte
- abgelehnte Inhalte
- Inhalte mit Risiko
- live Inhalte ohne Prüfung

## Veröffentlichungsschutz

Optional:

- Warnung bei ungeprüften Live-Inhalten
- Veröffentlichung blockieren bei kritischen Inhalten
- Feature-Status prüfen: geplant, Beta, verfügbar
