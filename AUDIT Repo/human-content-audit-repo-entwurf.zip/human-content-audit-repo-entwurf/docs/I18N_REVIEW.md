# I18N Review und Übersetzungen

## Grundregel

Deutsch kann als Primärsprache definiert werden. Übersetzungen müssen separat geprüft werden.

## Status ungeprüfter Übersetzungen

Ungeprüfte Übersetzungen sollten nicht automatisch als vollständig freigegeben gelten.

Mögliche Kennzeichnung:

- NEEDS_REVIEW
- TRANSLATION_UNVERIFIED
- APPROVED

## Hinweis für Übersetzungen

Bei nicht vollständig geprüften Übersetzungen:

```text
Übersetzung aus dem Deutschen. Übersetzungsfehler vorbehalten.
```

Bei rechtlichen Texten:

```text
Maßgeblich ist die deutsche Fassung. Übersetzungsfehler vorbehalten.
```

## Zusätzliche Checkliste bei Übersetzungen

- Übersetzung geprüft oder als ungeprüft markiert
- keine Sinnveränderung gegenüber Deutsch
- rechtliche Begriffe nicht frei oder falsch übersetzt
- Disclaimer erhalten
- Status sichtbar
- Sprache korrekt zugeordnet
