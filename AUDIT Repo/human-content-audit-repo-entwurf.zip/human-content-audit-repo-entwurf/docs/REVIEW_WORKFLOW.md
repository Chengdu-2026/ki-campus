# Review Workflow

## Statusfluss

```text
DRAFT
  -> NEEDS_REVIEW
  -> IN_REVIEW
  -> APPROVED
  -> PUBLISHED
```

Bei Problemen:

```text
IN_REVIEW
  -> CHANGES_REQUESTED
  -> NEEDS_REVIEW
```

Oder:

```text
IN_REVIEW
  -> REJECTED
```

## Auslöser für Prüfung

Ein Inhalt muss erneut geprüft werden, wenn:

- neuer Inhalt erstellt wurde
- bestehender Inhalt geändert wurde
- eine Übersetzung ergänzt wurde
- ein Feature-Text geändert wurde
- ein Zertifikatstext geändert wurde
- ein Rechtstext geändert wurde
- der Content-Hash nicht mehr zur freigegebenen Version passt

## Freigaberegel

Ein Inhalt gilt nur dann als geprüft, wenn:

- Status `APPROVED` oder `PUBLISHED`
- `approvedById` gesetzt
- `approvedAt` gesetzt
- aktueller `contentHash` entspricht freigegebenem Hash
- Review-Checkliste vollständig ist

## Kritische Inhalte

Diese Inhalte sollten Owner-Freigabe benötigen:

- Homepage-Hauptaussagen
- Zertifikatstexte
- AI-Act-Seiten
- ISO-/QM-Seiten
- Rechtlicher Hinweis
- KI-Transparenz
- Preis-/Leistungsversprechen
- Übersetzungen rechtlicher Texte
