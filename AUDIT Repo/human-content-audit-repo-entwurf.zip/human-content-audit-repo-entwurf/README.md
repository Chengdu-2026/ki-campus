# human-content-audit

**Human review workflow for AI-generated content.**

Dieses Repo-Konzept beschreibt ein generisches Audit- und Freigabesystem für KI-generierte oder KI-unterstützt geänderte Inhalte.

Ziel: nachvollziehbar dokumentieren, was geändert wurde, wer es geprüft hat, wann es freigegeben wurde und ob die aktuell veröffentlichte Version wirklich geprüft ist.

## Kurzbeschreibung

KI kann Inhalte erstellen. Der Mensch muss freigeben.

`human-content-audit` ist als generisches Modul gedacht für:

- Webseiten
- SaaS-Plattformen
- E-Learning-Systeme
- KI-generierte Blogartikel
- Produkttexte
- Rechtstexte
- Übersetzungen
- Helpcenter
- Zertifikatstexte
- Marketingseiten
- interne Richtlinien
- QM-Dokumentation
- ISO-orientierte Nachweise
- Content-Freigaben vor Veröffentlichung

## Was das System leisten soll

- Content erfassen
- Content-Hash berechnen
- Änderungen erkennen
- Status setzen: `needs_review`, `in_review`, `approved`, `changes_requested`, `published`
- Reviewer speichern
- Freigabezeitpunkt speichern
- Audit-Log schreiben
- riskante Begriffe scannen
- Übersetzungen markieren
- Export als JSON/CSV/PDF vorbereiten
- Admin-UI oder API bereitstellen

## Was das System nicht behaupten darf

Nicht schreiben:

- macht Inhalte rechtssicher
- garantiert Compliance
- ersetzt juristische Prüfung
- ISO-konform garantiert
- AI-Act-konform garantiert

Saubere Formulierung:

- unterstützt dokumentierte menschliche Prüfung
- macht Freigaben nachvollziehbar
- hilft, ungeprüfte KI-Inhalte zu erkennen
- unterstützt QM- und Audit-Prozesse

## Möglicher Repo-Name

Favorit:

```text
human-content-audit
```

Alternativen:

```text
ai-content-review-log
content-approval-audit-kit
human-review-log
```

## Lizenzempfehlung

Für Reichweite:

```text
MIT License
```

Für stärkeren Schutz gegen kommerzielle Weiterverwertung ohne Rückgabe:

```text
AGPL-3.0
```

Empfehlung für den Start: MIT License.
