# Lizenzhinweis

Empfehlung für öffentliche Verbreitung:

MIT License

Alternative, wenn kommerzielle Weiterverwertung stärker eingeschränkt werden soll:

AGPL-3.0

Für den Start wird MIT empfohlen, weil es die Verbreitung erleichtert.
