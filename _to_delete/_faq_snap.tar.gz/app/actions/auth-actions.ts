"use server";

import { z } from "zod";
import bcrypt from "bcryptjs";
import { randomUUID } from "crypto";
import { prisma } from "@/lib/prisma";
import { headers } from "next/headers";
import { audit } from "@/lib/audit";
import { sendMail } from "@/lib/mail";
import { appConfig } from "@/config/app";
import { isRateLimited, recordHit, clientIp } from "@/lib/rate-limit";

const passwordSchema = z.string().min(10, "passwordPolicy");

const registerSchema = z.object({
  companyName: z.string().min(2).max(200),
  firstName: z.string().min(1).max(100),
  lastName: z.string().min(1).max(100),
  email: z.string().email().max(200),
  password: passwordSchema,
});

export interface ActionResult {
  ok: boolean;
  error?: string;
}

/** Self-Service: legt Unternehmen (Plan BASIC) + ersten Unternehmensadmin an. */
export async function registerCompany(_prev: ActionResult | null, formData: FormData): Promise<ActionResult> {
  const parsed = registerSchema.safeParse({
    companyName: formData.get("companyName"),
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    email: String(formData.get("email") ?? "").toLowerCase().trim(),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message === "passwordPolicy" ? "auth.passwordPolicy" : "common.requiredField" };
  }
  const { companyName, firstName, lastName, email, password } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return { ok: false, error: "auth.emailExists" };

  const company = await prisma.company.create({
    data: { name: companyName, planKey: "BASIC" },
  });
  const user = await prisma.user.create({
    data: {
      email,
      passwordHash: await bcrypt.hash(password, 10),
      firstName,
      lastName,
      role: "COMPANY_ADMIN",
      companyId: company.id,
    },
  });

  await audit({ action: "COMPANY_CREATED", userId: user.id, companyId: company.id, entityType: "Company", entityId: company.id });
  await audit({ action: "USER_REGISTERED", userId: user.id, companyId: company.id, entityType: "User", entityId: user.id });
  await sendMail("verify_email", email, {
    firstName,
    link: `${process.env.APP_URL ?? ""}/login`,
    issuer: appConfig.certificateIssuer,
  });
  return { ok: true };
}

/** Passwort-Reset anfordern — antwortet immer gleich (kein Nutzer-Enumerations-Orakel). */
export async function requestPasswordReset(_prev: ActionResult | null, formData: FormData): Promise<ActionResult> {
  const email = String(formData.get("email") ?? "").toLowerCase().trim();
  if (!email) return { ok: false, error: "common.requiredField" };

  // Rate-Limit gegen Mail-Bombing (H2): pro IP und pro Ziel-E-Mail. Immer gleiche
  // Antwort (kein Enumerations-Orakel) — bei Überschreitung wird nur nichts versendet.
  const ip = clientIp({ headers: await headers() });
  const HOUR = 3600 * 1000;
  if (
    (ip !== "unknown" && isRateLimited(`reset:ip:${ip}`, 5, 15 * 60 * 1000)) ||
    isRateLimited(`reset:mail:${email}`, 5, HOUR)
  ) {
    return { ok: true };
  }
  if (ip !== "unknown") recordHit(`reset:ip:${ip}`, 15 * 60 * 1000);
  recordHit(`reset:mail:${email}`, HOUR);

  const user = await prisma.user.findUnique({ where: { email } });
  if (user && user.status === "ACTIVE") {
    // M2: alte, noch ungenutzte Reset-Tokens dieses Nutzers entwerten, damit nicht
    // mehrere gültige Reset-Links gleichzeitig existieren.
    await prisma.passwordResetToken.updateMany({
      where: { userId: user.id, usedAt: null },
      data: { usedAt: new Date() },
    });
    const token = randomUUID().replace(/-/g, "");
    await prisma.passwordResetToken.create({
      data: { userId: user.id, token, expiresAt: new Date(Date.now() + 3600 * 1000) },
    });
    await audit({ action: "PASSWORD_RESET_REQUESTED", userId: user.id, companyId: user.companyId });
    await sendMail("password_reset", email, {
      firstName: user.firstName,
      link: `${process.env.APP_URL ?? ""}/passwort-reset/${token}`,
      issuer: appConfig.certificateIssuer,
    }, user.locale);
  }
  return { ok: true };
}

export async function resetPassword(_prev: ActionResult | null, formData: FormData): Promise<ActionResult> {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  if (passwordSchema.safeParse(password).success === false) return { ok: false, error: "auth.passwordPolicy" };

  const reset = await prisma.passwordResetToken.findUnique({ where: { token }, include: { user: true } });
  if (!reset || reset.usedAt || reset.expiresAt < new Date()) return { ok: false, error: "auth.resetInvalid" };

  await prisma.$transaction([
    prisma.user.update({ where: { id: reset.userId }, data: { passwordHash: await bcrypt.hash(password, 10) } }),
    prisma.passwordResetToken.update({ where: { id: reset.id }, data: { usedAt: new Date() } }),
  ]);
  await audit({ action: "PASSWORD_RESET_DONE", userId: reset.userId, companyId: reset.user.companyId });
  return { ok: true };
}

const acceptInviteSchema = z.object({
  code: z.string().min(4),
  firstName: z.string().min(1).max(100),
  lastName: z.string().min(1).max(100),
  email: z.string().email().max(200),
  password: passwordSchema,
});

/** Einladung annehmen (Link-Code oder Registrierungscode) — erstellt Teilnehmer-Zugang. */
export async function acceptInvitation(_prev: ActionResult | null, formData: FormData): Promise<ActionResult> {
  const parsed = acceptInviteSchema.safeParse({
    code: String(formData.get("code") ?? "").trim(),
    firstName: formData.get("firstName"),
    lastName: formData.get("lastName"),
    email: String(formData.get("email") ?? "").toLowerCase().trim(),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues[0]?.message === "passwordPolicy" ? "auth.passwordPolicy" : "common.requiredField" };
  }
  const { code, firstName, lastName, email, password } = parsed.data;

  const invitation = await prisma.invitation.findUnique({ where: { code }, include: { company: { include: { plan: true, _count: { select: { users: { where: { status: "ACTIVE", role: "PARTICIPANT" } } } } } } } });
  if (!invitation || invitation.acceptedAt || invitation.expiresAt < new Date()) {
    return { ok: false, error: "auth.inviteInvalid" };
  }
  if (invitation.email && invitation.email.toLowerCase() !== email) {
    return { ok: false, error: "auth.inviteInvalid" };